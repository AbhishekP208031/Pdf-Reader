let pdfDoc = null,
    pageNum = 1,
    pageRendering = false,
    pageNumPending = null,
    scale = 1.2,
    canvas = document.getElementById("pdf-render"),
    ctx = canvas.getContext("2d");

document.getElementById("file-input").addEventListener("change", (e) => {
  let file = e.target.files[0];
  if (file.type !== "application/pdf") {
    alert("Please upload a PDF file.");
    return;
  }
  let fileReader = new FileReader();
  fileReader.onload = function() {
    let typedarray = new Uint8Array(this.result);
    pdfjsLib.getDocument(typedarray).promise.then((pdf) => {
      pdfDoc = pdf;
      pageNum = 1;
      renderPage(pageNum);
    });
  };
  fileReader.readAsArrayBuffer(file);
});

function renderPage(num) {
  pageRendering = true;
  pdfDoc.getPage(num).then((page) => {
    let viewport = page.getViewport({ scale: scale });
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    let renderContext = {
      canvasContext: ctx,
      viewport: viewport,
    };
    let renderTask = page.render(renderContext);

    renderTask.promise.then(() => {
      pageRendering = false;
      document.getElementById("page-info").textContent = `Page ${num} of ${pdfDoc.numPages}`;
    });
  });
}

document.getElementById("prev-page").addEventListener("click", () => {
  if (pageNum <= 1) return;
  pageNum--;
  renderPage(pageNum);
});

document.getElementById("next-page").addEventListener("click", () => {
  if (pageNum >= pdfDoc.numPages) return;
  pageNum++;
  renderPage(pageNum);
});
